import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Moradas de Paraty",
  description: "Da natureza ao novo lugar de viver em Paraty.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <head>
        <link
          rel="preload"
          href="/moradas/scroll-01-natureza-loteamento.webp"
          as="image"
          type="image/webp"
        />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
