"use client";

import type { CSSProperties } from "react";
import { useEffect, useRef, useState } from "react";

type Scene = {
  src: string;
  start: number;
  end: number;
  ratio: number;
};

const scenes: Scene[] = [
  {
    src: "/moradas/scroll-01-natureza-loteamento.webp",
    start: 0,
    end: 0.3,
    ratio: 1983 / 793,
  },
  {
    src: "/moradas/scroll-02-loteamento-casa.webp",
    start: 0.24,
    end: 0.55,
    ratio: 1947 / 808,
  },
  {
    src: "/moradas/scroll-03-caminho-porta.webp",
    start: 0.49,
    end: 0.79,
    ratio: 1942 / 809,
  },
  {
    src: "/moradas/scroll-04-casa-interior.webp",
    start: 0.73,
    end: 1,
    ratio: 1940 / 811,
  },
];

const chapters = [
  {
    start: -0.018,
    end: 0.095,
    label: "LOTEAMENTO RESIDENCIAL · PARATY / RJ",
    title: "Invista em Paraty\ncom tranquilidade.",
    text: "Lotes de alto padrão entre a Mata Atlântica e o Centro Histórico. Um lugar para viver, construir e valorizar.",
    align: "left",
  },
  {
    start: 0.1,
    end: 0.19,
    label: "ENTRE A SERRA E O CENTRO",
    title: "A natureza\ncomo endereço.",
    text: "Cercado de mata, cachoeiras e trilhas — a apenas nove minutos do coração colonial de Paraty.",
    align: "right",
  },
  {
    start: 0.205,
    end: 0.295,
    label: "O EMPREENDIMENTO",
    title: "250 a 450 m²\nprontos para construir.",
    text: "Lotes residenciais e comerciais, regulares e planos, em um bairro planejado e integrado ao relevo natural.",
    align: "left",
  },
  {
    start: 0.315,
    end: 0.405,
    label: "INFRAESTRUTURA ENTREGUE",
    title: "Nada ficou\nno papel.",
    text: "Água, luz, vias pavimentadas, sinalização e iluminação já fazem parte do Moradas de Paraty.",
    align: "right",
  },
  {
    start: 0.425,
    end: 0.515,
    label: "FACILIDADE",
    title: "Sua casa,\nsem complicação.",
    text: "Financiamento direto com o loteador, sem banco e sem burocracia, em até 240 vezes.",
    align: "left",
  },
  {
    start: 0.54,
    end: 0.635,
    label: "ESTILO DE VIDA",
    title: "Caminhos que\nlevam para casa.",
    text: "Playground, espaço pet, academia ao ar livre e áreas verdes preservadas para viver com mais tempo e presença.",
    align: "right",
  },
  {
    start: 0.66,
    end: 0.755,
    label: "CURADORIA ARQUITETÔNICA",
    title: "Uma paisagem\nfeita para durar.",
    text: "Diretrizes arquitetônicas preservam a harmonia entre as casas, a vegetação e a identidade de Paraty.",
    align: "left",
  },
  {
    start: 0.785,
    end: 0.885,
    label: "O SEU LUGAR",
    title: "Entre.\nA casa é sua.",
    text: "Construa quando quiser e transforme um investimento sólido em uma nova forma de viver.",
    align: "right",
  },
] as const;

const benefits = [
  ["9 min", "do Centro Histórico"],
  ["250–450 m²", "lotes residenciais e comerciais"],
  ["Até 240x", "direto com o loteador"],
] as const;

function clamp(value: number, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

function range(value: number, start: number, end: number) {
  return clamp((value - start) / (end - start));
}

function easeInOutCubic(value: number) {
  return value < 0.5
    ? 4 * value * value * value
    : 1 - Math.pow(-2 * value + 2, 3) / 2;
}

export default function Home() {
  const storyRef = useRef<HTMLElement>(null);
  const [progress, setProgress] = useState(0);
  const [viewport, setViewport] = useState({ width: 1440, height: 900 });

  useEffect(() => {
    const updateViewport = () =>
      setViewport({ width: innerWidth, height: innerHeight });

    updateViewport();
    addEventListener("resize", updateViewport);
    return () => removeEventListener("resize", updateViewport);
  }, []);

  useEffect(() => {
    let raf = 0;

    const update = () => {
      const story = storyRef.current;
      if (!story) return;
      const rect = story.getBoundingClientRect();
      const distance = story.offsetHeight - innerHeight;
      setProgress(clamp(-rect.top / Math.max(distance, 1)));
      raf = 0;
    };

    const requestUpdate = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };

    update();
    addEventListener("scroll", requestUpdate, { passive: true });
    addEventListener("resize", requestUpdate);
    return () => {
      cancelAnimationFrame(raf);
      removeEventListener("scroll", requestUpdate);
      removeEventListener("resize", requestUpdate);
    };
  }, []);

  const activeChapter = chapters.reduce(
    (current, chapter, index) =>
      Math.abs(progress - (chapter.start + chapter.end) / 2) <
      Math.abs(
        progress -
          (chapters[current].start + chapters[current].end) / 2,
      )
        ? index
        : current,
    0,
  );

  const finalReveal = range(progress, 0.935, 0.988);
  const finalStyle = {
    opacity: finalReveal,
    transform: `translate3d(-50%, ${(1 - finalReveal) * 45}px, 0)`,
    pointerEvents: finalReveal > 0.9 ? "auto" : "none",
    "--final-reveal": finalReveal,
  } as CSSProperties;

  return (
    <main>
      <section
        className="scroll-story"
        ref={storyRef}
        aria-label="Descubra o Moradas de Paraty"
      >
        <div className="scroll-stage">
          <div className="scene-stack" aria-hidden="true">
            {scenes.map((scene, index) => {
              const local = range(progress, scene.start, scene.end);
              const easedLocal = easeInOutCubic(local);
              const fadeDuration = 0.06;
              const fadeIn =
                scene.start === 0
                  ? 1
                  : range(progress, scene.start, scene.start + fadeDuration);
              const fadeOut =
                scene.end === 1
                  ? 1
                  : 1 - range(progress, scene.end - fadeDuration, scene.end);
              const opacity = fadeIn * fadeOut;
              const mobile = viewport.width < 761;
              const imageHeight = Math.max(
                viewport.width * scene.ratio,
                viewport.height * (mobile ? 1.75 : 2.12),
              );
              const travel = imageHeight - viewport.height;
              const y = -travel * easedLocal;
              const foregroundY = y - easedLocal * 72;

              return (
                <div className="scroll-scene" key={scene.src} style={{ opacity }}>
                  <img
                    className="scene-image"
                    src={scene.src}
                    alt=""
                    draggable={false}
                    decoding="async"
                    loading={index < 2 ? "eager" : "lazy"}
                    fetchPriority={index === 0 ? "high" : "auto"}
                    style={{
                      height: imageHeight,
                      transform: `translate3d(0, ${y}px, 0)`,
                    }}
                  />
                  <img
                    className="scene-image scene-foreground"
                    src={scene.src}
                    alt=""
                    draggable={false}
                    decoding="async"
                    loading="lazy"
                    style={{
                      height: imageHeight,
                      transform: `translate3d(0, ${foregroundY}px, 0) scale(1.025)`,
                    }}
                  />
                </div>
              );
            })}
          </div>

          <div className="cinematic-grade" aria-hidden="true" />

          <header className="topbar">
            <img src="/moradas/logo-moradas-de-paraty.svg" alt="Moradas de Paraty" />
            <a href="#contato">Quero mais informações</a>
          </header>

          <div className="chapter-stack" aria-live="polite">
            {chapters.map((chapter, index) => {
              const edge = 0.018;
              const enter = range(progress, chapter.start, chapter.start + edge);
              const exit =
                1 - range(progress, chapter.end - edge, chapter.end);
              const opacity = Math.min(enter, exit);
              const signedMotion = -(1 - enter) + (1 - exit);
              const horizontalDirection = chapter.align === "left" ? 1 : -1;
              const horizontal = signedMotion * 110 * horizontalDirection;
              const vertical = -signedMotion * 24;
              const scale = 0.98 + opacity * 0.02;
              const copyStyle = {
                opacity,
                transform: `translate3d(${horizontal}px, ${vertical}px, 0) scale(${scale})`,
                filter: `blur(${Math.abs(signedMotion) * 3.5}px)`,
                "--copy-motion": signedMotion,
                "--copy-visible": opacity,
              } as CSSProperties;
              return (
                <article
                  className={`story-copy story-copy--${chapter.align}`}
                  key={chapter.label}
                  aria-hidden={activeChapter !== index}
                  style={copyStyle}
                >
                  <p className="story-label">{chapter.label}</p>
                  <h1>
                    {chapter.title.split("\n").map((line) => (
                      <span key={line}>{line}</span>
                    ))}
                  </h1>
                  <p className="story-text">{chapter.text}</p>
                </article>
              );
            })}
          </div>

          <aside className="chapter-index" aria-hidden="true">
            <span>{String(activeChapter + 1).padStart(2, "0")}</span>
            <i>
              <b style={{ transform: `scaleY(${Math.max(progress, 0.015)})` }} />
            </i>
            <span>{String(chapters.length).padStart(2, "0")}</span>
          </aside>

          <div
            className="scroll-instruction"
            style={{ opacity: 1 - range(progress, 0.012, 0.065) }}
            aria-hidden="true"
          >
            <span>Role para entrar</span>
            <i />
          </div>

          <section
            className="final-card"
            id="contato"
            style={finalStyle}
          >
            <p className="story-label">MORADAS DE PARATY</p>
            <h2>Receba a apresentação completa.</h2>
            <p>
              Conheça os lotes disponíveis, a tabela de valores e as condições
              especiais diretamente com a equipe do empreendimento.
            </p>
            <div className="benefit-row">
              {benefits.map(([value, label]) => (
                <div key={value}>
                  <strong>{value}</strong>
                  <span>{label}</span>
                </div>
              ))}
            </div>
            <a
              className="primary-action"
              href="https://moradas-paraty.lovable.app/#formulario"
            >
              Quero mais informações <span>→</span>
            </a>
            <small>Rod. Paraty–Cunha, 489 · Pantanal · Paraty / RJ</small>
          </section>
        </div>
      </section>

      <footer className="legal-footer">
        <div>
          <strong>Moradas de Paraty</strong>
          <span>Loteamento Residencial Sophia Saíde</span>
        </div>
        <p>
          Matrícula nº 3487A · Comarca de Paraty / RJ · © 2026 Moradas de
          Paraty
        </p>
      </footer>
    </main>
  );
}
